"use client"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Heading1,
  Heading2,
  Heading3,
  Quote,
  List,
  ListOrdered,
  ImageIcon,
  Music,
  Palette,
  Eye,
  Type,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface RichTextEditorProps {
  content: any
  onChange: (content: any) => void
  layoutStyle: string
  onLayoutChange: (layout: string) => void
}

const layoutOptions = [
  { id: "default", name: "Classic", description: "Traditional book layout" },
  { id: "modern", name: "Modern", description: "Clean, minimalist design" },
  { id: "elegant", name: "Elegant", description: "Sophisticated typography" },
  { id: "magazine", name: "Magazine", description: "Multi-column layout" },
  { id: "journal", name: "Journal", description: "Personal diary style" },
]

export function RichTextEditor({ content, onChange, layoutStyle, onLayoutChange }: RichTextEditorProps) {
  const [activeFormats, setActiveFormats] = useState<Set<string>>(new Set())
  const [showLayoutPanel, setShowLayoutPanel] = useState(false)

  const toggleFormat = useCallback(
    (format: string) => {
      const newFormats = new Set(activeFormats)
      if (newFormats.has(format)) {
        newFormats.delete(format)
      } else {
        newFormats.add(format)
      }
      setActiveFormats(newFormats)
    },
    [activeFormats],
  )

  const insertHeading = useCallback((level: number) => {
    // Implementation would insert heading at cursor position
    console.log(`[v0] Inserting heading level ${level}`)
  }, [])

  const insertQuote = useCallback(() => {
    console.log("[v0] Inserting quote block")
  }, [])

  const insertList = useCallback((ordered: boolean) => {
    console.log(`[v0] Inserting ${ordered ? "ordered" : "unordered"} list`)
  }, [])

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Story Editor</CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant={showLayoutPanel ? "default" : "outline"}
                size="sm"
                onClick={() => setShowLayoutPanel(!showLayoutPanel)}
              >
                <Palette className="mr-2 h-4 w-4" />
                Layout
              </Button>
              <Button variant="outline" size="sm">
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Layout Selection Panel */}
          {showLayoutPanel && (
            <div className="p-4 bg-muted/50 rounded-lg space-y-3">
              <h4 className="font-medium flex items-center">
                <Type className="mr-2 h-4 w-4" />
                Choose Layout Style
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {layoutOptions.map((layout) => (
                  <button
                    key={layout.id}
                    onClick={() => onLayoutChange(layout.id)}
                    className={cn(
                      "p-3 text-left border rounded-lg hover:bg-background transition-colors",
                      layoutStyle === layout.id ? "border-primary bg-primary/5" : "border-border",
                    )}
                  >
                    <div className="font-medium text-sm">{layout.name}</div>
                    <div className="text-xs text-muted-foreground mt-1">{layout.description}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Formatting Toolbar */}
          <div className="flex flex-wrap items-center gap-1">
            {/* Text Formatting */}
            <div className="flex items-center">
              <Button
                variant={activeFormats.has("bold") ? "default" : "ghost"}
                size="sm"
                onClick={() => toggleFormat("bold")}
              >
                <Bold className="h-4 w-4" />
              </Button>
              <Button
                variant={activeFormats.has("italic") ? "default" : "ghost"}
                size="sm"
                onClick={() => toggleFormat("italic")}
              >
                <Italic className="h-4 w-4" />
              </Button>
              <Button
                variant={activeFormats.has("underline") ? "default" : "ghost"}
                size="sm"
                onClick={() => toggleFormat("underline")}
              >
                <Underline className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Headings */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm" onClick={() => insertHeading(1)}>
                <Heading1 className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => insertHeading(2)}>
                <Heading2 className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => insertHeading(3)}>
                <Heading3 className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Alignment */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm">
                <AlignLeft className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <AlignCenter className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <AlignRight className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Lists and Quotes */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm" onClick={() => insertList(false)}>
                <List className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={() => insertList(true)}>
                <ListOrdered className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={insertQuote}>
                <Quote className="h-4 w-4" />
              </Button>
            </div>

            <Separator orientation="vertical" className="h-6" />

            {/* Media */}
            <div className="flex items-center">
              <Button variant="ghost" size="sm">
                <ImageIcon className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Music className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Current Layout Badge */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Current layout:</span>
              <Badge variant="outline">{layoutOptions.find((l) => l.id === layoutStyle)?.name || "Default"}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editor Content Area */}
      <Card className="min-h-[600px]">
        <CardContent className="p-0">
          <div
            className={cn(
              "min-h-[600px] p-8 focus:outline-none",
              layoutStyle === "modern" && "font-sans leading-relaxed",
              layoutStyle === "elegant" && "font-serif leading-loose",
              layoutStyle === "magazine" && "columns-2 gap-8",
              layoutStyle === "journal" && "font-mono text-sm leading-relaxed",
            )}
            contentEditable
            suppressContentEditableWarning
            style={{
              background: layoutStyle === "journal" ? "#fefdf8" : "transparent",
            }}
          >
            <div className="prose prose-lg max-w-none">
              <h1 className="text-3xl font-bold mb-6">Your Story Title</h1>
              <p className="text-muted-foreground mb-8">
                Start writing your story here. Use the toolbar above to format your text, add headings, insert images,
                and choose different layout styles to make your story beautiful and engaging.
              </p>
              <p>
                This rich text editor supports multiple formatting options and layout styles. You can create immersive
                reading experiences with background audio, beautiful typography, and responsive layouts that work great
                on all devices.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
