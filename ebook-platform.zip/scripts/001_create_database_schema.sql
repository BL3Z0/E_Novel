-- Create users profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  user_type TEXT CHECK (user_type IN ('publisher', 'reader')) NOT NULL DEFAULT 'reader',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create stories table for publishers
CREATE TABLE IF NOT EXISTS public.stories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  content JSONB NOT NULL, -- Rich text content with formatting
  cover_image_url TEXT,
  audio_url TEXT, -- Background music/audio
  layout_style TEXT DEFAULT 'default', -- Layout template choice
  is_published BOOLEAN DEFAULT FALSE,
  publisher_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create reading progress table
CREATE TABLE IF NOT EXISTS public.reading_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reader_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  story_id UUID NOT NULL REFERENCES public.stories(id) ON DELETE CASCADE,
  progress_percentage DECIMAL(5,2) DEFAULT 0,
  last_position JSONB, -- Store scroll position, chapter, etc.
  last_read_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(reader_id, story_id)
);

-- Create story categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create story_categories junction table
CREATE TABLE IF NOT EXISTS public.story_categories (
  story_id UUID REFERENCES public.stories(id) ON DELETE CASCADE,
  category_id UUID REFERENCES public.categories(id) ON DELETE CASCADE,
  PRIMARY KEY (story_id, category_id)
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reading_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.story_categories ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- RLS Policies for stories
CREATE POLICY "Publishers can manage their own stories" ON public.stories
  FOR ALL USING (auth.uid() = publisher_id);

CREATE POLICY "Everyone can view published stories" ON public.stories
  FOR SELECT USING (is_published = TRUE OR auth.uid() = publisher_id);

-- RLS Policies for reading progress
CREATE POLICY "Users can manage their own reading progress" ON public.reading_progress
  FOR ALL USING (auth.uid() = reader_id);

-- RLS Policies for categories (public read, admin write)
CREATE POLICY "Everyone can view categories" ON public.categories
  FOR SELECT TO authenticated USING (TRUE);

CREATE POLICY "Everyone can view story categories" ON public.story_categories
  FOR SELECT TO authenticated USING (TRUE);
