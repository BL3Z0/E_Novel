-- Insert default story categories
INSERT INTO public.categories (name, description) VALUES
  ('Fiction', 'Fictional stories and novels'),
  ('Romance', 'Love stories and romantic fiction'),
  ('Mystery', 'Mystery and thriller stories'),
  ('Fantasy', 'Fantasy and magical stories'),
  ('Science Fiction', 'Sci-fi and futuristic stories'),
  ('Horror', 'Horror and suspense stories'),
  ('Adventure', 'Adventure and action stories'),
  ('Drama', 'Dramatic and emotional stories'),
  ('Comedy', 'Humorous and light-hearted stories'),
  ('Historical', 'Historical fiction and period stories')
ON CONFLICT (name) DO NOTHING;
