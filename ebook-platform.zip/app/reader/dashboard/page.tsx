import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { StoryCacheManager } from "@/components/story-cache-manager"
import { BookOpen, Search, TrendingUp, Clock, Heart, User, Download } from "lucide-react"
import Link from "next/link"

export default async function ReaderDashboard() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.user_type !== "reader") {
    redirect("/publisher/dashboard")
  }

  // Get published stories
  const { data: stories } = await supabase
    .from("stories")
    .select(`
      *,
      profiles!stories_publisher_id_fkey(full_name)
    `)
    .eq("is_published", true)
    .order("created_at", { ascending: false })
    .limit(12)

  // Get user's reading progress
  const { data: readingProgress } = await supabase
    .from("reading_progress")
    .select(`
      *,
      stories(title, cover_image_url)
    `)
    .eq("reader_id", user.id)
    .order("last_read_at", { ascending: false })
    .limit(6)

  // Get categories
  const { data: categories } = await supabase.from("categories").select("*").order("name")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BookOpen className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Reader Dashboard</h1>
                <p className="text-muted-foreground">Welcome back, {profile.full_name}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search stories..." className="pl-10 w-64" />
              </div>
              <Button asChild variant="outline">
                <Link href="/reader/profile">
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Continue Reading Section */}
            {readingProgress && readingProgress.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold flex items-center">
                    <Clock className="mr-2 h-5 w-5" />
                    Continue Reading
                  </h2>
                  <Button asChild variant="outline" size="sm">
                    <Link href="/reader/library">View All</Link>
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {readingProgress.slice(0, 3).map((progress) => (
                    <Card key={progress.id} className="group hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="w-12 h-16 bg-muted rounded flex-shrink-0 flex items-center justify-center">
                            <BookOpen className="h-6 w-6 text-muted-foreground" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium line-clamp-2 mb-1">{progress.stories?.title}</h3>
                            <div className="w-full bg-muted rounded-full h-2 mb-2">
                              <div
                                className="bg-primary h-2 rounded-full transition-all"
                                style={{ width: `${progress.progress_percentage}%` }}
                              />
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {Math.round(progress.progress_percentage)}% complete
                            </p>
                            <Button asChild size="sm" className="mt-2">
                              <Link href={`/story/${progress.story_id}`}>Continue</Link>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Categories */}
            {categories && categories.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Browse by Category</h2>
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <Button key={category.id} asChild variant="outline" size="sm">
                      <Link href={`/reader/category/${category.id}`}>{category.name}</Link>
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Featured Stories */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5" />
                  Featured Stories
                </h2>
                <Button asChild variant="outline" size="sm">
                  <Link href="/reader/browse">Browse All</Link>
                </Button>
              </div>

              {stories && stories.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {stories.map((story) => (
                    <Card key={story.id} className="group hover:shadow-lg transition-all duration-200">
                      <CardHeader className="pb-3">
                        <div className="aspect-[3/4] bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg mb-3 flex items-center justify-center">
                          <BookOpen className="h-12 w-12 text-primary/50" />
                        </div>
                        <CardTitle className="text-lg line-clamp-2 group-hover:text-primary transition-colors">
                          {story.title}
                        </CardTitle>
                        <CardDescription className="line-clamp-2">
                          {story.description || "A captivating story awaits..."}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">by {story.profiles?.full_name || "Anonymous"}</span>
                            <Badge variant="outline">{story.layout_style}</Badge>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Button asChild size="sm" className="flex-1">
                              <Link href={`/story/${story.id}`}>Read Story</Link>
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Heart className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="text-center py-12">
                  <CardContent>
                    <BookOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <CardTitle className="mb-2">No stories available</CardTitle>
                    <CardDescription>Check back later for new stories to read!</CardDescription>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <StoryCacheManager />
          </div>
        </div>
      </div>
    </div>
  )
}
