import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { BookOpen, Search, Filter, Heart, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function BrowseStoriesPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get all published stories
  const { data: stories } = await supabase
    .from("stories")
    .select(`
      *,
      profiles!stories_publisher_id_fkey(full_name)
    `)
    .eq("is_published", true)
    .order("created_at", { ascending: false })

  // Get categories
  const { data: categories } = await supabase.from("categories").select("*").order("name")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/reader/dashboard">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </Button>
              <div className="flex items-center space-x-4">
                <BookOpen className="h-8 w-8 text-primary" />
                <div>
                  <h1 className="text-2xl font-bold">Browse Stories</h1>
                  <p className="text-muted-foreground">Discover your next great read</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search stories by title, author, or description..." className="pl-10" />
          </div>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>

        {/* Categories */}
        {categories && categories.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold mb-4">Categories</h2>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm">
                All Stories
              </Button>
              {categories.map((category) => (
                <Button key={category.id} variant="ghost" size="sm">
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Stories Grid */}
        {stories && stories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {stories.map((story) => (
              <Card key={story.id} className="group hover:shadow-lg transition-all duration-200">
                <CardHeader className="pb-3">
                  <div className="aspect-[3/4] bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg mb-3 flex items-center justify-center">
                    <BookOpen className="h-12 w-12 text-primary/50" />
                  </div>
                  <CardTitle className="text-lg line-clamp-2 group-hover:text-primary transition-colors">
                    {story.title}
                  </CardTitle>
                  <CardDescription className="line-clamp-3">
                    {story.description || "A captivating story awaits your discovery..."}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">by {story.profiles?.full_name || "Anonymous"}</span>
                      <Badge variant="outline">{story.layout_style}</Badge>
                    </div>

                    <div className="text-xs text-muted-foreground">
                      Published {new Date(story.created_at).toLocaleDateString()}
                    </div>

                    <div className="flex items-center space-x-2">
                      <Button asChild size="sm" className="flex-1">
                        <Link href={`/story/${story.id}`}>Read Story</Link>
                      </Button>
                      <Button variant="outline" size="sm">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-16">
            <CardContent>
              <BookOpen className="h-20 w-20 text-muted-foreground mx-auto mb-6" />
              <CardTitle className="text-2xl mb-4">No stories found</CardTitle>
              <CardDescription className="text-lg mb-6">
                Try adjusting your search or check back later for new stories.
              </CardDescription>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
