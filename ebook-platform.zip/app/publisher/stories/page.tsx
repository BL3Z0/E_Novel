import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { PlusCircle, BookOpen, Edit, Eye, Search, Filter } from "lucide-react"
import Link from "next/link"

export default async function PublisherStoriesPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile || profile.user_type !== "publisher") {
    redirect("/reader/dashboard")
  }

  // Get all publisher's stories
  const { data: stories } = await supabase
    .from("stories")
    .select("*")
    .eq("publisher_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BookOpen className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">My Stories</h1>
                <p className="text-muted-foreground">Manage all your published content</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button asChild variant="outline">
                <Link href="/publisher/dashboard">Dashboard</Link>
              </Button>
              <Button asChild>
                <Link href="/publisher/stories/new">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  New Story
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search and Filter */}
        <div className="flex items-center space-x-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search stories..." className="pl-10" />
          </div>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </div>

        {/* Stories Grid */}
        {stories && stories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stories.map((story) => (
              <Card key={story.id} className="group hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1 flex-1">
                      <CardTitle className="text-lg line-clamp-2">{story.title}</CardTitle>
                      <CardDescription className="line-clamp-3">
                        {story.description || "No description provided"}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge variant={story.is_published ? "default" : "secondary"}>
                        {story.is_published ? "Published" : "Draft"}
                      </Badge>
                      <div className="text-sm text-muted-foreground">
                        {new Date(story.created_at).toLocaleDateString()}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Button asChild size="sm" className="flex-1">
                        <Link href={`/publisher/stories/${story.id}/edit`}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </Link>
                      </Button>
                      <Button asChild variant="outline" size="sm" className="flex-1 bg-transparent">
                        <Link href={`/story/${story.id}`}>
                          <Eye className="mr-2 h-4 w-4" />
                          Preview
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-16">
            <CardContent>
              <BookOpen className="h-20 w-20 text-muted-foreground mx-auto mb-6" />
              <CardTitle className="text-2xl mb-4">No stories yet</CardTitle>
              <CardDescription className="text-lg mb-6 max-w-md mx-auto">
                Start your publishing journey by creating your first story. Share your creativity with readers around
                the world.
              </CardDescription>
              <Button asChild size="lg">
                <Link href="/publisher/stories/new">
                  <PlusCircle className="mr-2 h-5 w-5" />
                  Create Your First Story
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
