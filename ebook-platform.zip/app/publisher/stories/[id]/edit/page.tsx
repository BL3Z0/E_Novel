"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { RichTextEditor } from "@/components/rich-text-editor"
import { ArrowLeft, Save, Music, ImageIcon, Eye } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

interface Story {
  id: string
  title: string
  description: string
  content: any
  cover_image_url: string | null
  audio_url: string | null
  layout_style: string
  is_published: boolean
  publisher_id: string
  created_at: string
  updated_at: string
}

export default function EditStoryPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [story, setStory] = useState<Story | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadStory()
  }, [params.id])

  const loadStory = async () => {
    const supabase = createClient()

    try {
      const { data, error } = await supabase.from("stories").select("*").eq("id", params.id).single()

      if (error) throw error
      setStory(data)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Failed to load story")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = async () => {
    if (!story) return

    setIsSaving(true)
    const supabase = createClient()

    try {
      const { error } = await supabase
        .from("stories")
        .update({
          title: story.title,
          description: story.description,
          content: story.content,
          layout_style: story.layout_style,
          is_published: story.is_published,
          updated_at: new Date().toISOString(),
        })
        .eq("id", story.id)

      if (error) throw error

      toast({
        title: "Story saved",
        description: "Your changes have been saved successfully.",
      })
    } catch (error: unknown) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save story",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleContentChange = (content: any) => {
    if (story) {
      setStory({ ...story, content })
    }
  }

  const handleLayoutChange = (layoutStyle: string) => {
    if (story) {
      setStory({ ...story, layout_style: layoutStyle })
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading story...</p>
        </div>
      </div>
    )
  }

  if (error || !story) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Error</CardTitle>
            <CardDescription>{error || "Story not found"}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/publisher/stories">Back to Stories</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/publisher/stories">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Stories
                </Link>
              </Button>
              <div>
                <h1 className="text-xl font-bold">Edit Story</h1>
                <p className="text-sm text-muted-foreground">
                  Last saved: {new Date(story.updated_at).toLocaleString()}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </Button>
              <Button onClick={handleSave} disabled={isSaving}>
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Editor */}
          <div className="lg:col-span-3">
            <RichTextEditor
              content={story.content}
              onChange={handleContentChange}
              layoutStyle={story.layout_style}
              onLayoutChange={handleLayoutChange}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Story Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Story Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={story.title}
                    onChange={(e) => setStory({ ...story, title: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={story.description || ""}
                    onChange={(e) => setStory({ ...story, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="published"
                    checked={story.is_published}
                    onCheckedChange={(checked) => setStory({ ...story, is_published: checked })}
                  />
                  <Label htmlFor="published">Published</Label>
                </div>
              </CardContent>
            </Card>

            {/* Media */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Media</CardTitle>
                <CardDescription>Add cover image and background audio</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Cover Image</Label>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <ImageIcon className="mr-2 h-4 w-4" />
                    {story.cover_image_url ? "Change Image" : "Upload Image"}
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Background Audio</Label>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Music className="mr-2 h-4 w-4" />
                    {story.audio_url ? "Change Audio" : "Upload Audio"}
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Audio will play in the background while readers enjoy your story
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Publishing */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Publishing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <span className={story.is_published ? "text-green-600" : "text-yellow-600"}>
                      {story.is_published ? "Published" : "Draft"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created:</span>
                    <span>{new Date(story.created_at).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Updated:</span>
                    <span>{new Date(story.updated_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
