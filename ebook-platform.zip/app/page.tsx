import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, PenTool, User, Headphones, Palette, Download } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <BookOpen className="h-16 w-16 text-primary" />
          </div>
          <h1 className="text-5xl font-bold text-balance mb-6">
            Your Stories, <span className="text-primary">Beautifully Told</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty mb-8">
            Create immersive ebooks with rich formatting, background audio, and offline reading. Perfect for publishers
            and readers who love beautiful storytelling.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="text-lg px-8">
              <Link href="/auth/signup">Get Started</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 bg-transparent">
              <Link href="/auth/login">Sign In</Link>
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          <Card className="text-center">
            <CardHeader>
              <PenTool className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Rich Text Editor</CardTitle>
              <CardDescription>
                Create beautiful stories with advanced formatting, layouts, and styling options
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Headphones className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Background Audio</CardTitle>
              <CardDescription>
                Add immersive soundtracks and audio that plays while readers enjoy your stories
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Download className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Offline Reading</CardTitle>
              <CardDescription>
                Stories are cached for offline access, perfect for reading anywhere without data
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Palette className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Custom Layouts</CardTitle>
              <CardDescription>
                Choose from beautiful page layouts and designs to make your stories stand out
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <User className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Reader Profiles</CardTitle>
              <CardDescription>Track reading progress, save favorites, and discover new stories</CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <BookOpen className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Publisher Tools</CardTitle>
              <CardDescription>
                Complete dashboard for managing your stories, analytics, and reader engagement
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl">Ready to Start Your Story?</CardTitle>
              <CardDescription className="text-lg">
                Join thousands of publishers and readers creating beautiful ebook experiences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild size="lg">
                  <Link href="/auth/signup">
                    <PenTool className="mr-2 h-4 w-4" />
                    Start Publishing
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/auth/signup">
                    <User className="mr-2 h-4 w-4" />
                    Start Reading
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
